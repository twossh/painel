<?php
//by jean gomes


if(isset($_SESSION['id'])){
	
	echo 1;
	
	return;
}


if(serves($_POST['server']) == "notserver"){
	
	echo "Servidor nao encontrado!!!";
	return;
}else{
	
	include('Net/SSH2.php');
	
	$server = serves($_POST['server']);
	
$ssh = new Net_SSH2(''.$server['ip']);
if (!$ssh->login('root', ''.$server['pass'])) {
    exit('Login Failed');
}
	
	
$nome = "ssh-".chr(rand(65,90)) . chr(rand(65,90)) . chr(rand(65,90)) . chr(rand(65,90)) . chr(rand(65,90));
$senha = rand(999,99999);

	
	$log = $ssh->exec("useradd ".$nome);
	
	
	if($log != null){

echo "<small style='color: white'>Conta <b style='color: red;'>$nome</b> ja existem!!!</small>";




}else {

 $ssh->setTimeout(1);
$ssh->read('username@username:~$');
$ssh->write("passwd $nome \n"); 
$ssh->read('username@username:~$');
$ssh->write($senha."\n");
$ssh->read('username@username:~$');
$ssh->write($senha."\n");
$ssh->read(); 


}

}





echo "<h3>SSH Criado com sucesso!!!</h3>";
echo "<br>";
echo "Host IP Addr :  $server[ip]";
echo "<br>";
echo "Squid proxy :  $server[ip]:8080";
echo "<br>";
echo "Port SSH: 443,22";
echo "<br>";
echo "Username SSH: ".$nome;
echo "<br>";
echo "Password SSH: ".$senha;
echo "<br>";




$query = $conn->query("INSERT INTO `sshfree`(nome, senha, tempo, ip, iphost) VALUES ('$nome','$senha',NOW(),'$ip','$_POST[server]')");


$query1 = $conn->query("SELECT * FROM `sshfree` WHERE nome='$nome'");
$fetch = $query1->fetch_array(MYSQLI_ASSOC);


$_SESSION['id'] = $fetch['id'];
$_SESSION['id'] = $fetch['id'];
$cookie_name = "id";




